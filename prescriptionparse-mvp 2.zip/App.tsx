import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Camera, FileText, Mic, RefreshCw, ShoppingCart, Loader2, ArrowLeft, CheckCircle2, X } from 'lucide-react';
import { AppState, ProcessingLog, PrescriptionResponse, Medication, Patient } from './types';
import { preprocessImage } from './services/imageProcessing';
import { parsePrescriptionWithGemini, parseVoiceInputWithGemini } from './services/geminiService';
import { ProcessingSteps } from './components/ProcessingSteps';
import { CartReview } from './components/ReviewForm';
import { TTS_CART_TEMPLATE } from './constants';

const INITIAL_LOGS: ProcessingLog[] = [
  { step: 'Upload Image', status: 'pending', timestamp: 0 },
  { step: 'Preprocessing (Deskew/Denoise)', status: 'pending', timestamp: 0 },
  { step: 'Gemini OCR & Parse', status: 'pending', timestamp: 0 },
  { step: 'Adding to Cart', status: 'pending', timestamp: 0 },
];

const DUPLICATE_WINDOW_MS = 5000; // 5 seconds to prevent accidental duplicate adds

export default function App() {
  const [appState, setAppState] = useState<AppState>(AppState.HOME);
  const [showChoiceModal, setShowChoiceModal] = useState(false);
  
  const [logs, setLogs] = useState<ProcessingLog[]>(INITIAL_LOGS);
  
  // Cart State
  const [medications, setMedications] = useState<Medication[]>([]);
  const [patient, setPatient] = useState<Patient>({ name: null, dob: null });
  const [humanReviewRequired, setHumanReviewRequired] = useState(false);
  
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  
  // Voice State
  const [isListening, setIsListening] = useState(false);
  const [isProcessingVoice, setIsProcessingVoice] = useState(false);
  const [transcriptDisplay, setTranscriptDisplay] = useState("");
  
  // Refs for Voice Logic
  const recognitionRef = useRef<any>(null);
  const transcriptBufferRef = useRef(''); // Accumulates speech chunks
  const voiceTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null); // Debounce timer
  const recentAddsRef = useRef<Record<string, number>>({}); // Dedupe map
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Helpers ---
  const normalizeNameForKey = (name?: string | null) => {
    if (!name) return 'unknown';
    return name.toLowerCase().replace(/[^a-z0-9]/g, '');
  };

  const speak = useCallback((text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); 
      const utterance = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utterance);
    }
  }, []);

  // --- Voice Logic (Debounce + Dedupe + Intents) ---
  const processVoiceBuffer = useCallback(async () => {
    const text = transcriptBufferRef.current.trim();
    if (!text) return;
    
    // Clear buffer immediately to prevent double processing
    transcriptBufferRef.current = '';
    setIsProcessingVoice(true);
    
    try {
      const result = await parseVoiceInputWithGemini(text);
      
      // Handle Intents
      if (result.intent === 'confirm') {
        speak("Order placed. Thank you!");
        setAppState(AppState.SUCCESS);
        return;
      }
      
      if (result.intent === 'done') {
        speak("Opening cart for review.");
        setAppState(AppState.CART_REVIEW);
        return;
      }
      
      if (result.intent === 'remove') {
          // Simplistic remove: filter out matches
          const keyToRemove = normalizeNameForKey(result.name_normalized || result.name_raw);
          if (keyToRemove) {
              setMedications(prev => prev.filter(m => normalizeNameForKey(m.name_normalized || m.name_raw) !== keyToRemove));
              speak(`Removed ${result.name_normalized || result.name_raw || 'item'}.`);
          }
          return;
      }

      if ((result.intent === 'add' || result.intent === 'unknown') && result.name_raw && result.confidence > 0.4) {
        const nameKey = normalizeNameForKey(result.name_normalized || result.name_raw);
        const now = Date.now();
        
        // Deduplication Check
        if (recentAddsRef.current[nameKey] && (now - recentAddsRef.current[nameKey] < DUPLICATE_WINDOW_MS)) {
           // Skip adding, maybe just update user
           console.log("Duplicate add blocked for:", nameKey);
           speak(`I already added ${result.name_normalized || result.name_raw}.`);
           return;
        }

        const newMed: Medication = {
          name_raw: result.name_raw,
          name_normalized: result.name_normalized,
          quantity: result.quantity || 1,
          dose: null,
          frequency: null,
          confidence: result.confidence
        };
        
        setMedications(prev => [...prev, newMed]);
        recentAddsRef.current[nameKey] = now; // Mark timestamp
        speak(`Added ${result.name_normalized || result.name_raw}, quantity ${result.quantity}.`);
      } else if (result.intent === 'unknown') {
        speak("I didn't catch that medicine name. Please repeat.");
      }

    } catch (e: any) {
      console.error("Voice Processing Error", e);
      if (e.message && e.message.includes("429")) {
        speak("I'm getting too many requests. Please wait a moment.");
      } else {
        speak("Sorry, I had trouble understanding that.");
      }
    } finally {
      setIsProcessingVoice(false);
      setTranscriptDisplay(""); // Clear display after processing
    }
  }, [speak]);

  // --- Voice Setup ---
  useEffect(() => {
    if (typeof window !== 'undefined' && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const instance = new SpeechRecognition();
      instance.continuous = true; // KEEP LISTENING
      instance.interimResults = true; // Get chunks for display
      instance.lang = 'en-US';
      recognitionRef.current = instance;
    } else {
        setErrorMsg("Speech recognition is not supported in this browser.");
    }
    
    return () => {
        if (recognitionRef.current) {
            recognitionRef.current.abort();
        }
    };
  }, []);

  const toggleListening = useCallback(() => {
    const recognition = recognitionRef.current;
    if (!recognition) return;

    if (isListening) {
      recognition.stop();
      setIsListening(false);
      // clear any pending timeout
      if (voiceTimeoutRef.current) clearTimeout(voiceTimeoutRef.current);
    } else {
      setErrorMsg(null);
      setTranscriptDisplay("");
      transcriptBufferRef.current = "";
      
      recognition.onstart = () => setIsListening(true);
      
      recognition.onresult = (event: any) => {
        let interim = '';
        let finalChunk = '';
        
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalChunk += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        
        // Update UI
        setTranscriptDisplay(finalChunk || interim || "Listening...");

        // Accumulate final chunks into buffer
        if (finalChunk) {
            transcriptBufferRef.current += ' ' + finalChunk;
            
            // DEBOUNCE LOGIC: Reset timer on every new chunk
            if (voiceTimeoutRef.current) clearTimeout(voiceTimeoutRef.current);
            
            // Wait 2 seconds of silence before sending to Gemini
            voiceTimeoutRef.current = setTimeout(() => {
                processVoiceBuffer();
            }, 2000);
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error === 'not-allowed') {
            setErrorMsg("Microphone access denied. Please allow microphone permissions.");
        } else if (event.error !== 'no-speech') {
            console.error("Speech error", event.error);
        }
      };
      
      recognition.onend = () => {
          // If we want it to be truly continuous/always-on, we might restart it here.
          // For now, let's allow it to stop if user stops speaking for a LONG time or manually.
          // But usually continuous=true keeps it going until stop() is called.
          // If it stops unexpectedly, we update state.
          setIsListening(false);
      };

      try {
        recognition.start();
      } catch (err) {
        setIsListening(false);
      }
    }
  }, [isListening, processVoiceBuffer]);


  // --- File Flow ---
  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setAppState(AppState.PREPROCESSING);
    setShowChoiceModal(false);
    setLogs(INITIAL_LOGS.map(l => ({ ...l, status: 'pending' })));
    setMedications([]);
    setErrorMsg(null);
    setProcessedImage(null);

    updateLog(0, 'completed');

    try {
      updateLog(1, 'active');
      const base64Img = await preprocessImage(file);
      setProcessedImage(base64Img);
      updateLog(1, 'completed');

      updateLog(2, 'active');
      setAppState(AppState.OCR_PROCESSING);
      const imageId = `img_${Date.now()}`;
      
      const data = await parsePrescriptionWithGemini(base64Img, imageId);
      updateLog(2, 'completed');

      updateLog(3, 'active');
      setMedications(data.medications);
      setPatient(data.patient);
      setHumanReviewRequired(data.human_review_required || data.medications.some(m => m.confidence < 0.6));
      updateLog(3, 'completed');

      const itemNames = data.medications.map((m, i) => 
        `${i + 1} — ${m.name_normalized || m.name_raw}, quantity ${m.quantity}`
      ).join('. ');
      const ttsText = TTS_CART_TEMPLATE
        .replace('{N}', data.medications.length.toString())
        .replace('{ITEMS}', itemNames);
      speak(ttsText);

      setAppState(AppState.CART_REVIEW);

    } catch (err) {
      console.error(err);
      setAppState(AppState.ERROR);
      setErrorMsg(err instanceof Error ? err.message : "Unknown error occurred");
    }
  };

  const updateLog = (index: number, status: ProcessingLog['status']) => {
    setLogs(prev => {
      const newLogs = [...prev];
      newLogs[index] = { ...newLogs[index], status, timestamp: Date.now() };
      return newLogs;
    });
  };

  const resetApp = () => {
    setAppState(AppState.HOME);
    setShowChoiceModal(false);
    setLogs(INITIAL_LOGS);
    setMedications([]);
    setProcessedImage(null);
    setTranscriptDisplay("");
    if (fileInputRef.current) fileInputRef.current.value = '';
    window.speechSynthesis.cancel();
    if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch(e) {}
    }
    setIsListening(false);
  };

  // --- Renderers ---

  const renderHome = () => (
    <div className="flex flex-col items-center justify-center min-h-[60vh] gap-8 px-4 animate-fade-in text-center relative">
      <div>
        <h1 className="text-4xl font-extrabold text-gray-900 mb-2 tracking-tight">MediShopAI</h1>
        <p className="text-gray-500 text-lg">Your intelligent health assistant</p>
      </div>
      
      <button 
        onClick={() => setShowChoiceModal(true)}
        className="group relative inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-blue-600 font-lg rounded-full hover:bg-blue-700 hover:shadow-lg hover:-translate-y-1 focus:outline-none ring-offset-2 focus:ring-2"
      >
        Start Conversation
      </button>

      {/* Choice Modal */}
      {showChoiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl p-8 max-w-sm w-full shadow-2xl relative">
            <button 
              onClick={() => setShowChoiceModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X className="w-6 h-6" />
            </button>
            
            <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">How would you like to order?</h2>
            
            <div className="space-y-4">
              <button 
                 onClick={() => fileInputRef.current?.click()}
                 className="w-full flex items-center gap-4 p-4 rounded-xl border-2 border-gray-100 hover:border-blue-500 hover:bg-blue-50 transition-all group"
              >
                 <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
                   <Camera className="w-6 h-6" />
                 </div>
                 <div className="text-left">
                   <div className="font-bold text-gray-900">Upload Prescription</div>
                   <div className="text-xs text-gray-500">Scan paper rx</div>
                 </div>
              </button>

              <button 
                 onClick={() => {
                   setAppState(AppState.VOICE_MODE);
                   setShowChoiceModal(false);
                   speak("I'm listening. Please tell me what medicines you need.");
                   // Small timeout to allow state transition before starting mic
                   setTimeout(() => toggleListening(), 500); 
                 }}
                 className="w-full flex items-center gap-4 p-4 rounded-xl border-2 border-gray-100 hover:border-purple-500 hover:bg-purple-50 transition-all group"
              >
                 <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 group-hover:scale-110 transition-transform">
                   <Mic className="w-6 h-6" />
                 </div>
                 <div className="text-left">
                   <div className="font-bold text-gray-900">Voice Ordering</div>
                   <div className="text-xs text-gray-500">Hands-free mode</div>
                 </div>
              </button>
            </div>
          </div>
        </div>
      )}

      <input 
        ref={fileInputRef}
        type="file" 
        accept="image/*" 
        capture="environment"
        className="hidden" 
        onChange={handleFileSelect}
      />
    </div>
  );

  const renderVoiceMode = () => (
    <div className="flex flex-col items-center justify-center min-h-[50vh] px-4 animate-fade-in">
      
      {/* Voice Status Widget */}
      <div className="mb-8 relative">
        <div className={`voice-pulse ${isListening ? 'opacity-100' : 'opacity-50 grayscale'}`}>
            <Mic className={`w-12 h-12 ${isListening ? 'text-green-600' : 'text-gray-400'}`} />
        </div>
        {isProcessingVoice && (
            <div className="absolute inset-0 flex items-center justify-center bg-white/80 rounded-full backdrop-blur-sm z-10">
                <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
            </div>
        )}
      </div>

      <h2 className="text-3xl font-bold text-gray-900 mb-2">
        {isProcessingVoice ? "Thinking..." : isListening ? "I'm listening..." : "Mic paused"}
      </h2>
      
      <p className="text-gray-500 mb-8 h-8 text-center font-medium">
        {transcriptDisplay || (isListening ? "Speak clearly..." : "Tap mic to resume")}
      </p>

      {/* Controls */}
      <div className="flex gap-4">
        <button 
          onClick={toggleListening}
          className={`px-8 py-3 rounded-full font-bold shadow-md transition-all hover:scale-105 ${isListening ? 'bg-white text-gray-900 border border-gray-200' : 'bg-green-600 text-white hover:bg-green-700'}`}
        >
          {isListening ? 'Pause Mic' : 'Start Mic'}
        </button>
        <button 
          onClick={() => setAppState(AppState.CART_REVIEW)}
          className="px-8 py-3 bg-gray-900 text-white rounded-full font-bold shadow-md hover:bg-black transition-all"
        >
          View Cart
        </button>
      </div>
      
      {/* Transcript Bubbles / Hints */}
      <div className="mt-12 flex flex-wrap justify-center gap-2 max-w-md">
         <span className="bg-white px-3 py-1 rounded-full text-xs text-gray-400 border shadow-sm">"Add Paracetamol"</span>
         <span className="bg-white px-3 py-1 rounded-full text-xs text-gray-400 border shadow-sm">"Remove Amoxicillin"</span>
         <span className="bg-white px-3 py-1 rounded-full text-xs text-gray-400 border shadow-sm">"Checkout"</span>
      </div>

      {medications.length > 0 && (
        <div className="mt-8 bg-white/60 backdrop-blur rounded-xl border border-white/50 p-4 w-full max-w-sm shadow-sm">
             <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-bold uppercase text-gray-500">Recently Added</span>
                <span className="text-xs font-bold bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">{medications.length}</span>
             </div>
             <div className="text-sm text-gray-800 font-medium truncate">
                {medications[medications.length-1].name_normalized || medications[medications.length-1].name_raw}
             </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col font-sans text-gray-900">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-40 border-b border-gray-100">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-xl text-gray-900 cursor-pointer hover:opacity-80 transition-opacity" onClick={resetApp}>
                <div className="w-8 h-8 bg-gradient-to-tr from-blue-600 to-teal-400 rounded-lg flex items-center justify-center text-white">
                    <FileText className="w-5 h-5" />
                </div>
                <span>MediShopAI</span>
            </div>
            {appState !== AppState.HOME && appState !== AppState.SUCCESS && (
                <button onClick={resetApp} className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition-colors">
                    <RefreshCw className="w-5 h-5" />
                </button>
            )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-5xl mx-auto px-4 w-full py-8">
        
        {appState === AppState.HOME && renderHome()}
        
        {appState === AppState.VOICE_MODE && renderVoiceMode()}

        {(appState === AppState.PREPROCESSING || appState === AppState.OCR_PROCESSING) && (
            <div className="mt-12 flex flex-col items-center animate-fade-in">
                <ProcessingSteps logs={logs} />
                {processedImage && (
                    <div className="mt-8 relative group">
                         <img src={processedImage} alt="Processing" className="h-48 w-auto rounded-xl shadow-2xl opacity-90 transition-all duration-700" />
                         <div className="absolute inset-0 flex items-center justify-center bg-black/10 rounded-xl">
                            <Loader2 className="w-10 h-10 text-white animate-spin drop-shadow-md" />
                         </div>
                    </div>
                )}
            </div>
        )}

        {appState === AppState.CART_REVIEW && (
             <div className="animate-fade-in">
                 <button onClick={() => setAppState(AppState.VOICE_MODE)} className="mb-4 flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-blue-600 transition-colors">
                    <ArrowLeft className="w-4 h-4" /> Back to Voice Mode
                 </button>
                 <CartReview 
                    medications={medications}
                    patient={patient}
                    humanReviewRequired={humanReviewRequired}
                    onConfirm={() => {
                        setAppState(AppState.SUCCESS);
                        speak("Order confirmed. Processing your prescription.");
                    }}
                 />
             </div>
        )}

        {appState === AppState.SUCCESS && (
            <div className="flex flex-col items-center justify-center py-12 px-4 animate-fade-in">
                <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6 shadow-sm">
                    <CheckCircle2 className="w-12 h-12 text-green-600" />
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-2">Order Placed!</h1>
                <p className="text-gray-600 mb-8 text-lg">Thank you for shopping with MediShopAI.</p>
                <button 
                    onClick={resetApp} 
                    className="px-8 py-3 bg-gray-900 text-white rounded-full font-bold hover:bg-black transition-all shadow-lg hover:-translate-y-1"
                >
                    Start New Order
                </button>
            </div>
        )}

        {appState === AppState.ERROR && (
            <div className="text-center mt-20 animate-fade-in">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <X className="w-8 h-8 text-red-500" />
                </div>
                <div className="text-red-500 mb-2 font-bold text-xl">Something went wrong</div>
                <p className="text-gray-600 mb-6 max-w-md mx-auto">{errorMsg}</p>
                <button onClick={resetApp} className="px-6 py-2 bg-gray-200 rounded-lg hover:bg-gray-300 font-medium">Try Again</button>
            </div>
        )}

      </main>
    </div>
  );
}