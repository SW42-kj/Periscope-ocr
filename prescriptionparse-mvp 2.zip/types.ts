export interface Medication {
  name_raw: string | null;
  name_normalized: string | null;
  quantity: number;
  dose: string | null;
  frequency: string | null;
  confidence: number;
}

export interface Patient {
  name: string | null;
  dob: string | null;
}

export interface Doctor {
  name: string | null;
  reg_no: string | null;
}

export interface PrescriptionResponse {
  image_id: string;
  timestamp: string;
  summary?: string | null;
  medications: Medication[];
  patient: Patient;
  doctor?: Doctor;
  flags: string[];
  human_review_required: boolean;
  error: string | null;
}

export interface VoiceCommandResponse {
  raw: string;
  name_raw: string | null;
  name_normalized: string | null;
  quantity: number;
  confidence: number;
  intent: 'add' | 'remove' | 'confirm' | 'done' | 'unknown';
}

export enum AppState {
  HOME = 'HOME',
  CAPTURING = 'CAPTURING',
  PREPROCESSING = 'PREPROCESSING',
  OCR_PROCESSING = 'OCR_PROCESSING',
  LLM_PARSING = 'LLM_PARSING',
  REVIEW_REQUIRED = 'REVIEW_REQUIRED',
  VOICE_MODE = 'VOICE_MODE',
  CART_REVIEW = 'CART_REVIEW',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export interface ProcessingLog {
  step: string;
  status: 'pending' | 'active' | 'completed' | 'error';
  timestamp: number;
}