/**
 * Simulates the "Preprocess" step:
 * - Resize to manageable dimensions (upscale if too small)
 * - Grayscale
 * - Contrast enhancement
 * Returns a base64 string (image/jpeg).
 */
export const preprocessImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          reject(new Error("Could not get canvas context"));
          return;
        }

        // 1. Upscale/Resize logic (Min width 1024 for better OCR)
        let width = img.width;
        let height = img.height;
        const minWidth = 1024;
        
        if (width < minWidth) {
          const scale = minWidth / width;
          width = minWidth;
          height = height * scale;
        }
        
        // Cap max size to avoid token limits or browser memory issues
        const maxDimension = 2048;
        if (width > maxDimension || height > maxDimension) {
            const scale = maxDimension / Math.max(width, height);
            width = width * scale;
            height = height * scale;
        }

        canvas.width = width;
        canvas.height = height;

        // Draw original
        ctx.drawImage(img, 0, 0, width, height);

        // 2. Grayscale & Contrast (Simple Pixel Manipulation)
        const imageData = ctx.getImageData(0, 0, width, height);
        const data = imageData.data;
        
        // Contrast factor (1.2 = +20% contrast)
        const contrast = 1.2;
        const intercept = 128 * (1 - contrast);

        for (let i = 0; i < data.length; i += 4) {
          // Grayscale (Luma)
          const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
          
          // Apply contrast
          let newColor = gray * contrast + intercept;
          newColor = Math.min(255, Math.max(0, newColor));

          data[i] = newColor;     // R
          data[i + 1] = newColor; // G
          data[i + 2] = newColor; // B
          // Alpha remains same
        }

        ctx.putImageData(imageData, 0, 0);

        // Export as JPEG with high quality
        resolve(canvas.toDataURL('image/jpeg', 0.9));
      };
      img.onerror = (e) => reject(e);
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
};