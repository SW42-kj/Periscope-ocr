import { GoogleGenAI, Type } from "@google/genai";
import { 
  PRODUCTION_SYSTEM_PROMPT, 
  PRODUCTION_USER_PROMPT_TEMPLATE,
  VOICE_SYSTEM_PROMPT,
  VOICE_USER_PROMPT_TEMPLATE
} from "../constants";
import { PrescriptionResponse, VoiceCommandResponse } from "../types";

// Schema for Prompt A
const prescriptionSchema = {
  type: Type.OBJECT,
  properties: {
    image_id: { type: Type.STRING },
    timestamp: { type: Type.STRING },
    medications: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name_raw: { type: Type.STRING, nullable: true },
          name_normalized: { type: Type.STRING, nullable: true },
          quantity: { type: Type.INTEGER },
          dose: { type: Type.STRING, nullable: true },
          frequency: { type: Type.STRING, nullable: true },
          confidence: { type: Type.NUMBER },
        },
        required: ["confidence", "quantity"],
      },
    },
    patient: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, nullable: true },
        dob: { type: Type.STRING, nullable: true },
      },
    },
    flags: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    human_review_required: { type: Type.BOOLEAN },
    error: { type: Type.STRING, nullable: true },
  },
  required: ["image_id", "timestamp", "medications", "human_review_required"],
};

// Schema for Prompt B
const voiceCommandSchema = {
  type: Type.OBJECT,
  properties: {
    raw: { type: Type.STRING },
    name_raw: { type: Type.STRING, nullable: true },
    name_normalized: { type: Type.STRING, nullable: true },
    quantity: { type: Type.INTEGER },
    confidence: { type: Type.NUMBER },
    intent: { type: Type.STRING, enum: ['add', 'remove', 'confirm', 'done', 'unknown'] },
  },
  required: ["raw", "quantity", "confidence", "intent"],
};

const getAiClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const parsePrescriptionWithGemini = async (
  base64Image: string,
  imageId: string
): Promise<PrescriptionResponse> => {
  const ai = getAiClient();
  const cleanBase64 = base64Image.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash", 
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: cleanBase64,
            },
          },
          {
            text: PRODUCTION_USER_PROMPT_TEMPLATE
              .replace(/<IMAGE_ID>/g, imageId)
              .replace("<OCR_TEXT>", "[Extract text from the attached prescription image]")
          },
        ],
      },
      config: {
        systemInstruction: PRODUCTION_SYSTEM_PROMPT,
        responseMimeType: "application/json",
        responseSchema: prescriptionSchema,
        temperature: 0.1,
      },
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from Gemini");

    return JSON.parse(text) as PrescriptionResponse;

  } catch (error) {
    console.error("Gemini Prescription Parse Error:", error);
    throw error;
  }
};

export const parseVoiceInputWithGemini = async (
  spokenText: string
): Promise<VoiceCommandResponse> => {
  const ai = getAiClient();

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [{
          text: VOICE_USER_PROMPT_TEMPLATE.replace("<RAW_STT_TEXT>", spokenText)
        }],
      },
      config: {
        systemInstruction: VOICE_SYSTEM_PROMPT,
        responseMimeType: "application/json",
        responseSchema: voiceCommandSchema,
        temperature: 0.1,
      },
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from Gemini");

    return JSON.parse(text) as VoiceCommandResponse;
  } catch (error) {
    console.error("Gemini Voice Parse Error:", error);
    throw error;
  }
};