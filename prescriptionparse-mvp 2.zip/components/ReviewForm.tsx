import React, { useState, useEffect, useMemo } from 'react';
import { Medication, Patient, Doctor } from '../types';
import { AlertTriangle, Save, Trash2, ShoppingCart, Plus, Minus, Pill } from 'lucide-react';

interface CartReviewProps {
  medications: Medication[];
  patient: Patient;
  doctor?: Doctor;
  humanReviewRequired: boolean;
  onConfirm: (meds: Medication[], patient: Patient) => void;
  onAddItem?: () => void;
}

const normalizeNameForKey = (name?: string | null) => {
  if (!name) return 'unknown';
  return name.toLowerCase().replace(/[^a-z0-9]/g, '');
};

export const CartReview: React.FC<CartReviewProps> = ({ 
  medications, 
  patient, 
  humanReviewRequired, 
  onConfirm 
}) => {
  // We manage local state as a flat list, but UI will render grouped by name
  const [localMeds, setLocalMeds] = useState<Medication[]>(medications);
  const [localPatient, setLocalPatient] = useState<Patient>(patient);

  useEffect(() => {
    setLocalMeds(medications);
    setLocalPatient(patient);
  }, [medications, patient]);

  // Group medications by normalized name for display
  const groupedMeds = useMemo(() => {
    const map = new Map<string, { med: Medication, count: number, indices: number[] }>();
    
    localMeds.forEach((med, index) => {
      const key = normalizeNameForKey(med.name_normalized || med.name_raw);
      if (!map.has(key)) {
        map.set(key, { med: { ...med }, count: 0, indices: [] });
      }
      const entry = map.get(key)!;
      entry.count += med.quantity; // Sum up quantities
      entry.indices.push(index);
    });

    return Array.from(map.values());
  }, [localMeds]);

  const updateQuantity = (key: string, delta: number) => {
    // This is a simplified logic: we find the first item matching the key and update its quantity
    // In a real app with product IDs, this would be cleaner.
    const newMeds = [...localMeds];
    const targetIndex = newMeds.findIndex(m => normalizeNameForKey(m.name_normalized || m.name_raw) === key);
    
    if (targetIndex !== -1) {
      const currentQty = newMeds[targetIndex].quantity;
      const newQty = currentQty + delta;
      
      if (newQty <= 0) {
        // Remove item
        newMeds.splice(targetIndex, 1);
      } else {
        newMeds[targetIndex].quantity = newQty;
      }
      setLocalMeds(newMeds);
    }
  };

  const handleAddNew = () => {
    setLocalMeds([...localMeds, {
      name_raw: 'New Medicine',
      name_normalized: 'New Medicine',
      quantity: 1,
      dose: '',
      frequency: '',
      confidence: 1.0
    }]);
  };

  const handleSave = () => {
    onConfirm(localMeds, localPatient);
  };

  return (
    <div className="w-full max-w-3xl mx-auto bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl border border-white/50 overflow-hidden">
      
      {humanReviewRequired && (
        <div className="bg-orange-50 p-4 border-b border-orange-100 flex items-center gap-3 animate-fade-in">
          <AlertTriangle className="text-orange-500 w-6 h-6" />
          <div>
            <h2 className="text-lg font-bold text-gray-800">Review Required</h2>
            <p className="text-sm text-gray-600">Please verify the medications below.</p>
          </div>
        </div>
      )}

      <div className="p-6">
        
        {/* Cart Header */}
        <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                <ShoppingCart className="w-6 h-6 text-blue-600" />
                Your Cart
                <span className="bg-blue-100 text-blue-700 text-sm py-0.5 px-2 rounded-full">{groupedMeds.length} items</span>
            </h3>
            <button 
              onClick={handleAddNew}
              className="text-sm bg-blue-50 hover:bg-blue-100 text-blue-600 px-4 py-2 rounded-full font-medium transition-colors flex items-center gap-1"
            >
                <Plus className="w-4 h-4" /> Add Manual
            </button>
        </div>
        
        {/* Cart List */}
        <div className="space-y-4 mb-8">
            {groupedMeds.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                    <Pill className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">Your cart is empty.</p>
                </div>
            ) : (
                groupedMeds.map((group, idx) => {
                    const key = normalizeNameForKey(group.med.name_normalized || group.med.name_raw);
                    return (
                        <div key={idx} className="flex items-center gap-4 p-4 bg-white border border-gray-100 rounded-xl shadow-sm hover:shadow-md transition-shadow">
                            {/* Thumbnail */}
                            <div className="w-16 h-16 bg-gray-50 rounded-lg flex items-center justify-center flex-shrink-0">
                                <Pill className="w-8 h-8 text-blue-300" />
                            </div>
                            
                            {/* Info */}
                            <div className="flex-1">
                                <h4 className="font-bold text-gray-900 text-lg">{group.med.name_normalized || group.med.name_raw}</h4>
                                <p className="text-sm text-gray-500">{group.med.dose || 'Standard dose'}</p>
                                {group.med.confidence < 0.6 && (
                                    <span className="inline-block mt-1 text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full">
                                        Low confidence
                                    </span>
                                )}
                            </div>

                            {/* Controls */}
                            <div className="flex items-center gap-3 bg-gray-50 rounded-full px-2 py-1">
                                <button 
                                    onClick={() => updateQuantity(key, -1)}
                                    className="p-1 hover:bg-gray-200 rounded-full text-gray-600"
                                >
                                    <Minus className="w-4 h-4" />
                                </button>
                                <span className="font-bold text-gray-900 w-6 text-center">{group.count}</span>
                                <button 
                                    onClick={() => updateQuantity(key, 1)}
                                    className="p-1 hover:bg-gray-200 rounded-full text-gray-600"
                                >
                                    <Plus className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    );
                })
            )}
        </div>

        {/* Patient Info */}
        <div className="bg-blue-50/50 p-4 rounded-xl mb-6">
            <h3 className="font-semibold text-gray-700 mb-2 text-xs uppercase tracking-wider">Patient Details</h3>
            <input 
              type="text" 
              placeholder="Patient Name (Optional)"
              value={localPatient.name || ''} 
              onChange={(e) => setLocalPatient({...localPatient, name: e.target.value})}
              className="w-full p-2.5 border border-blue-100 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            />
        </div>
        
        <div className="flex justify-end">
           <button 
             onClick={handleSave}
             disabled={localMeds.length === 0}
             className="flex items-center gap-2 px-8 py-4 bg-gray-900 hover:bg-black disabled:bg-gray-300 text-white font-bold text-lg rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
           >
             <Save className="w-5 h-5" />
             Confirm Order
           </button>
        </div>
      </div>
    </div>
  );
};