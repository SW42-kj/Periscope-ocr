import React from 'react';
import { CheckCircle2, Circle, Loader2 } from 'lucide-react';
import { ProcessingLog } from '../types';

interface ProcessingStepsProps {
  logs: ProcessingLog[];
}

export const ProcessingSteps: React.FC<ProcessingStepsProps> = ({ logs }) => {
  return (
    <div className="w-full max-w-md mx-auto bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Processing Pipeline</h3>
      <div className="space-y-4">
        {logs.map((log, index) => (
          <div key={index} className="flex items-center gap-3">
            <div className="flex-shrink-0 w-6">
              {log.status === 'completed' && (
                <CheckCircle2 className="w-6 h-6 text-green-500" />
              )}
              {log.status === 'active' && (
                <Loader2 className="w-6 h-6 text-blue-500 animate-spin" />
              )}
              {log.status === 'pending' && (
                <Circle className="w-6 h-6 text-gray-300" />
              )}
              {log.status === 'error' && (
                <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center">
                  <span className="text-red-500 text-xs font-bold">!</span>
                </div>
              )}
            </div>
            <div className="flex-1">
              <p className={`text-sm font-medium ${
                log.status === 'active' ? 'text-blue-600' : 
                log.status === 'completed' ? 'text-gray-900' : 
                'text-gray-400'
              }`}>
                {log.step}
              </p>
              {log.status === 'active' && (
                <p className="text-xs text-blue-400 animate-pulse">Processing...</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};